How to read result files

{frequency}_{plant name}_{data missingness}_{forecast horizon}_{metric}_{does it include weather}

15min_Noble Clinton_MCAR_24_steps_RMSE_results_weather
- Freq: 15 minute
- Plant: Noble Clinton
- Data missing: MCAR
- Horizon: 24 steps ahead
- Metric: RMSE
- Includes weather as feature